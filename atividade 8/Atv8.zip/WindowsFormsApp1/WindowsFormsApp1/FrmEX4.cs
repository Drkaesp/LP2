﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class FrmEX4 : Form
    {
        public FrmEX4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            int[] tamanhos = new int[10];

            // Limpar ListBox
            lstResultados.Items.Clear();

            // Carregar nomes
            for (int i = 0; i < 10; i++)
            {
                nomes[i] = Microsoft.VisualBasic.Interaction.InputBox(
                    $"Digite o nome completo da {i + 1}ª pessoa:", "Entrada de Nomes");

                // Calcular tamanho sem espaços
                tamanhos[i] = nomes[i].Replace(" ", "").Length;

                // Adicionar ao ListBox
                lstResultados.Items.Add($"{nomes[i]} - {tamanhos[i]} caracteres");
            }
    }
}
