﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 novoFormulario = new Form2();
            novoFormulario.Show();

            int[] numeros = new int[20];

            // Carregar números
            for (int i = 0; i < 20; i++)
            {
                string input = Microsoft.VisualBasic.Interaction.InputBox(
                    $"Digite o {i + 1}º número:", "Entrada de Dados");

                if (int.TryParse(input, out numeros[i]) == false)
                {
                    MessageBox.Show("Digite apenas números!");
                    i--; // Volta uma posição para repetir a entrada
                    continue;
                }
            }

            // Inverter e mostrar
            Array.Reverse(numeros);
            string resultado = string.Join(", \n", numeros);
            MessageBox.Show($"Números em ordem inversa:\n{resultado}");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmEX2 novoFormulario = new FrmEX2();
            novoFormulario.Show();

            ArrayList alunos = new ArrayList();

            // Adicionar alunos
            alunos.Add("Ana");
            alunos.Add("André");
            alunos.Add("Débora");
            alunos.Add("Fátima");
            alunos.Add("João");
            alunos.Add("Janete");
            alunos.Add("Otávio");
            alunos.Add("Marcelo");
            alunos.Add("Pedro");
            alunos.Add("Thais");

            // Remover Otávio
            alunos.Remove("Otávio");

            // Mostrar resultado
            string resultado = string.Join("\n", alunos.ToArray());
            MessageBox.Show($"Lista de alunos após remoção:\n{resultado}");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FrmEX3 novoFormulario = new FrmEX3();
            novoFormulario.Show();
            double[,] notas = new double[20, 3];
            StringBuilder resultado = new StringBuilder();

            // Carregar notas
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    while (true)
                    {
                        string input = Microsoft.VisualBasic.Interaction.InputBox(
                            $"Digite a nota {j + 1} do aluno {i + 1}:", "Entrada de Notas");

                        if (double.TryParse(input, out double nota) && nota >= 0 && nota <= 10)
                        {
                            notas[i, j] = nota;
                            break;
                        }
                        MessageBox.Show("Digite uma nota válida entre 0 e 10!");
                    }
                }

                // Calcular média
                double media = (notas[i, 0] + notas[i, 1] + notas[i, 2]) / 3;
                resultado.AppendLine($"Aluno {i + 1}: média {media:F1}");
            }

            MessageBox.Show(resultado.ToString());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            {
                FrmEX4 novoFormulario = new FrmEX4();
                novoFormulario.Show();
           
                }
            }
        }
    }
}
