﻿namespace WindowsFormsApp1
{
    partial class FrmEX4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstbxclear = new System.Windows.Forms.Button();
            this.lstbxresultado = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lstbxclear
            // 
            this.lstbxclear.Location = new System.Drawing.Point(90, 133);
            this.lstbxclear.Name = "lstbxclear";
            this.lstbxclear.Size = new System.Drawing.Size(121, 42);
            this.lstbxclear.TabIndex = 0;
            this.lstbxclear.Text = "lstResultados.Items.Clear";
            this.lstbxclear.UseVisualStyleBackColor = true;
            this.lstbxclear.Click += new System.EventHandler(this.button1_Click);
            // 
            // lstbxresultado
            // 
            this.lstbxresultado.FormattingEnabled = true;
            this.lstbxresultado.Location = new System.Drawing.Point(480, 66);
            this.lstbxresultado.Name = "lstbxresultado";
            this.lstbxresultado.Size = new System.Drawing.Size(280, 316);
            this.lstbxresultado.TabIndex = 1;
            // 
            // FrmEX4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lstbxresultado);
            this.Controls.Add(this.lstbxclear);
            this.Name = "FrmEX4";
            this.Text = "FrmEX4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button lstbxclear;
        private System.Windows.Forms.ListBox lstbxresultado;
    }
}