﻿namespace FormIMC
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtpeso = new TextBox();
            txtaltura = new TextBox();
            btcalcular = new Button();
            label3 = new Label();
            lbimc = new Label();
            lbclassificação = new Label();
            btlimpar = new Button();
            btsair = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(67, 68);
            label1.Name = "label1";
            label1.Size = new Size(32, 15);
            label1.TabIndex = 0;
            label1.Text = "peso";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(67, 131);
            label2.Name = "label2";
            label2.Size = new Size(37, 15);
            label2.TabIndex = 1;
            label2.Text = "altura";
            // 
            // txtpeso
            // 
            txtpeso.Location = new Point(157, 68);
            txtpeso.Name = "txtpeso";
            txtpeso.Size = new Size(100, 23);
            txtpeso.TabIndex = 2;
            txtpeso.TextChanged += txtpeso_TextChanged;
            // 
            // txtaltura
            // 
            txtaltura.Location = new Point(157, 128);
            txtaltura.Name = "txtaltura";
            txtaltura.Size = new Size(100, 23);
            txtaltura.TabIndex = 3;
            // 
            // btcalcular
            // 
            btcalcular.Location = new Point(157, 192);
            btcalcular.Name = "btcalcular";
            btcalcular.Size = new Size(100, 23);
            btcalcular.TabIndex = 4;
            btcalcular.Text = "Calcular IMC";
            btcalcular.UseVisualStyleBackColor = true;
            btcalcular.Click += btcalcular_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(176, 260);
            label3.Name = "label3";
            label3.Size = new Size(56, 15);
            label3.TabIndex = 5;
            label3.Text = "resultado";
            // 
            // lbimc
            // 
            lbimc.AutoSize = true;
            lbimc.Location = new Point(182, 300);
            lbimc.Name = "lbimc";
            lbimc.Size = new Size(29, 15);
            lbimc.TabIndex = 6;
            lbimc.Text = "IMC";
            lbimc.Visible = false;
            // 
            // lbclassificação
            // 
            lbclassificação.AutoSize = true;
            lbclassificação.Location = new Point(157, 330);
            lbclassificação.Name = "lbclassificação";
            lbclassificação.Size = new Size(75, 15);
            lbclassificação.TabIndex = 7;
            lbclassificação.Text = "Classificação";
            lbclassificação.Visible = false;
            // 
            // btlimpar
            // 
            btlimpar.Location = new Point(40, 192);
            btlimpar.Name = "btlimpar";
            btlimpar.Size = new Size(75, 23);
            btlimpar.TabIndex = 8;
            btlimpar.Text = "Limpar";
            btlimpar.UseVisualStyleBackColor = true;
            btlimpar.Click += btlimpar_Click;
            // 
            // btsair
            // 
            btsair.Location = new Point(287, 192);
            btsair.Name = "btsair";
            btsair.Size = new Size(75, 23);
            btsair.TabIndex = 9;
            btsair.Text = "Sair";
            btsair.UseVisualStyleBackColor = true;
            btsair.Click += btsair_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(387, 412);
            Controls.Add(btsair);
            Controls.Add(btlimpar);
            Controls.Add(lbclassificação);
            Controls.Add(lbimc);
            Controls.Add(label3);
            Controls.Add(btcalcular);
            Controls.Add(txtaltura);
            Controls.Add(txtpeso);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtpeso;
        private TextBox txtaltura;
        private Button btcalcular;
        private Label label3;
        private Label lbimc;
        private Label lbclassificação;
        private Button btlimpar;
        private Button btsair;
    }
}
