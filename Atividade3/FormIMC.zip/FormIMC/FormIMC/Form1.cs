namespace FormIMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label4_VisibleChanged(object sender, EventArgs e)
        {

        }

        private void btcalcular_Click(object sender, EventArgs e)
        {
            double peso;
            double altura;

            if (double.TryParse(txtpeso.Text, out peso) && double.TryParse(txtaltura.Text, out altura))
            {
                double imc = peso / (Math.Pow(altura * altura);
                imc = Math.Round(imc, 1);
                lbimc.Text = imc.ToString("F2");
                lbimc.Visible = true;

                string classificacao = string.Empty;

                if (imc < 16.9)
                    classificacao = "muito abaixo do peso";
                else if (imc >= 17 && imc <= 18.4)
                    classificacao = "Abaixo do peso";
                else if (imc >= 18.5 && imc <= 24.9)
                    classificacao = "peso normal";
                else if (imc >= 25 && imc <= 29.9)
                    classificacao = "acima do peso";
                else if (imc >= 30 && imc <= 34.9)
                    classificacao = "Obesidade Grau I";
                else if (imc >= 35 && imc <= 40)
                    classificacao = "Obesidade Grau II";
                else if (imc >= 40)
                    classificacao = "Obesidade Grau III";

                lbclassifica��o.Text = classificacao;
                lbclassifica��o.Visible = true;
            }
            else
            {
                // Handle invalid input
                lbimc.Text = "Invalid input";
                lbimc.Visible = true;
                lbclassifica��o.Text = "Invalid input";
                lbclassifica��o.Visible = true;
            }
        }

        private void btsair_Click(object sender, EventArgs e)
        {

        }

        private void btlimpar_Click(object sender, EventArgs e)
        {

        }
    }
}
